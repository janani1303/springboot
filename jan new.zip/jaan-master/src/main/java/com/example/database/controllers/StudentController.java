package com.example.database.controllers;

import com.example.database.dtos.StudentDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.services.StudentService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/student")
public class StudentController {

    private static final Logger LOGGER = LoggerFactory.getLogger( StudentController.class);

    @Autowired
    StudentService studentService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-student", method = RequestMethod.POST)
    public ResponseEntity<StudentDto> addStudent(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  StudentDto createStudentDto) {

        StudentDto responseStudentDto = null;
        try {
            responseStudentDto =  studentService. addStudent(createStudentDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        return new ResponseEntity<>(responseStudentDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-student", method = RequestMethod.GET)
    public ResponseEntity<List< StudentDto>> getAllStudent() {
        List< StudentDto>  StudentDtoList =  studentService.getStudents();
        return new ResponseEntity<>( StudentDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{studentName}", method = RequestMethod.GET)
    public ResponseEntity<StudentDto> getStudent( @PathVariable(value="studentName")String studentName) {
        StudentDto responseStudentDto = null;
        try {
            responseStudentDto =  studentService.getStudentByName(studentName);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseStudentDto, HttpStatus.OK);
    }


    @RequestMapping(value = "/update-student", method = RequestMethod.PUT)
    public ResponseEntity<StudentDto> updateStudent(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})StudentDto updateStudentDto) {
        StudentDto responseStudentDto = null;
        try {
            responseStudentDto =  studentService.updateStudent(updateStudentDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        return new ResponseEntity<>(responseStudentDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/delete-student/{id}", method = RequestMethod.DELETE)
    public String delete(@PathVariable Long id) {
        studentService.deleteById(id);
        return "Deleted";
    }

    @RequestMapping(value = "/delete-student", method = RequestMethod.DELETE)
    public String deleteAll() {
        studentService.deleteAll();
        return "Deleted";
    }



}