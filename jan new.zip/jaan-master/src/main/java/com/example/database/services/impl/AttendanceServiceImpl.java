package com.example.database.services.impl;

import com.example.database.dtos.AttendanceDto;
import com.example.database.entities.AttendanceEntity;
import com.example.database.entities.StudentEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.AttendanceMapper;
import com.example.database.repositories.AttendanceRepository;
import com.example.database.repositories.StudentRepository;
import com.example.database.services.AttendanceService;

import com.example.database.services.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class AttendanceServiceImpl implements AttendanceService {

    @Autowired
    AttendanceRepository attendanceRepository;

    @Autowired
    StudentRepository studentRepository;

    @Override
    public AttendanceDto addAttendance(AttendanceDto attendanceDto) throws ResourceExist {
        System.out.println(attendanceDto.getStudentId());
        AttendanceEntity attendanceEntity = attendanceRepository.getAttendanceById(attendanceDto.getId());
        if (attendanceEntity != null)
            throw new ResourceExist("Attendance name exist");

       StudentEntity studentEntity = studentRepository.findById(attendanceDto.getStudentId()).orElse(null);
        if(studentEntity==null)
            throw new ResourceNotFound("No such student exists");

        attendanceEntity =  AttendanceMapper.INSTANCE.toEntity(attendanceDto);
        attendanceEntity.setStudentEntity(studentEntity);
        attendanceEntity = attendanceRepository.save(attendanceEntity);
        return  AttendanceMapper.INSTANCE.toDto(attendanceEntity);
    }


    @Override
    public AttendanceDto getAttendanceById(Long id) throws ResourceNotFound {
        return Optional.ofNullable(attendanceRepository
                .getAttendanceById(id))
                .map(AttendanceMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Attendance not found"));
    }

    @Override
    public List<AttendanceDto> getAttendances() {
        return Optional.ofNullable(attendanceRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(AttendanceMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
    @Override
    public AttendanceDto updateAttendance(AttendanceDto attendanceDto) throws ResourceExist {
        AttendanceEntity attendanceEntity = attendanceRepository.getAttendanceEntityById(attendanceDto.getId());
        if(attendanceEntity==null)
            throw new ResourceNotFound("No such attendance exists");

        StudentEntity studentEntity = studentRepository.findById(attendanceDto.getStudentId()).orElse(null);
        if(studentEntity==null)
            throw new ResourceNotFound("No such student exists");

        attendanceEntity =  AttendanceMapper.INSTANCE.toEntity(attendanceDto);
        attendanceEntity.setStudentEntity(studentEntity);
        attendanceEntity = attendanceRepository.save(attendanceEntity);
        return  AttendanceMapper.INSTANCE.toDto(attendanceEntity);

    }
}
