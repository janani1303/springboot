package com.example.database.entities;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;

@Entity
@Table(name = "classroom")
@Getter
@Setter
public class ClassRoomEntity extends AuditEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "grade_id")
    private GradeEntity gradeEntity;

    @Column(name= "section")
    private Character section;


}