package com.example.database.repositories.impl;

import com.example.database.entities.ClassStudentEntity;
import com.example.database.entities.SubjectGradeEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class SubjectGradeRepositoryImpl
{
    @PersistenceContext
    private EntityManager entityManager;

    public SubjectGradeEntity findBySubjectGradeId(Long id) {
        Query query = entityManager.createNativeQuery("select * from subject_grade where id = " + id, SubjectGradeEntity.class);
        return (SubjectGradeEntity)  query.getSingleResult();
    }
}
