package com.example.database.repositories.impl;


import com.example.database.entities.TermEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class TermRepositoryImpl {
    @PersistenceContext
    private EntityManager entityManager;

    public TermEntity findByTermName(String name) {
        Query query = entityManager.createNativeQuery("select * from term where name = " + name, TermEntity.class);
        return (TermEntity)  query.getSingleResult();
    }
}
