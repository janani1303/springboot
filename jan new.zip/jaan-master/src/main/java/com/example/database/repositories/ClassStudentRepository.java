package com.example.database.repositories;

import com.example.database.entities.ClassStudentEntity;
import com.example.database.entities.StudentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ClassStudentRepository extends JpaRepository<StudentEntity,Long>
{
    @Query(value = "select * from class_student where id =:inpId",nativeQuery = true)
    ClassStudentEntity getClassStudentById(@Param("inpId") Long id);

//    @Query(value = "select * from Student where name =:name",nativeQuery = true)
//    StudentEntity getStudentByName(@Param("name") String name);

    ClassStudentEntity getClassStudentEntityById(Long Id);

    //ClassStudentEntity findByStudentName(String studentName);

}
