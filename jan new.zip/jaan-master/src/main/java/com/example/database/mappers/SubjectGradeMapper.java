package com.example.database.mappers;

import com.example.database.dtos.SubjectGradeDto;
import com.example.database.entities.SubjectGradeEntity;
import org.mapstruct.factory.Mappers;

public interface SubjectGradeMapper
{
    SubjectGradeMapper INSTANCE = Mappers.getMapper(SubjectGradeMapper .class);

    SubjectGradeEntity toEntity(SubjectGradeDto subjectGradeDto);
    SubjectGradeDto toDto( SubjectGradeEntity  subjectGradeEntity);
}
