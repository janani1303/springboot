package com.example.database.repositories.impl;

import com.example.database.entities.ClassStudentEntity;
import com.example.database.entities.GradeEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class ClassStudentRepositoryImpl
{
    @PersistenceContext
    private EntityManager entityManager;

    public ClassStudentEntity findByClassStudentId(Long id) {
        Query query = entityManager.createNativeQuery("select * from class_student where id = " + id, ClassStudentEntity.class);
        return (ClassStudentEntity)  query.getSingleResult();
    }
}
