package com.example.database.controllers;

import com.example.database.dtos.ClassStudentDto;
import com.example.database.dtos.StudentDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.entities.ClassRoomEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.repositories.ClassRoomRepository;
import com.example.database.services.ClassStudentService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/classStudent")
public class ClassStudentController
{
    private static final Logger LOGGER = LoggerFactory.getLogger( ClassStudentController.class);

    @Autowired
    ClassRoomRepository classRoomRepository;
    @Autowired
    ClassStudentService classStudentService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-classStudent", method = RequestMethod.POST)
    public ResponseEntity<ClassStudentDto> addClassStudent(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  ClassStudentDto createClassStudentDto) {

        ClassStudentDto responseClassStudentDto = null;
        try {
            responseClassStudentDto =  classStudentService. addClassStudent(createClassStudentDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        ClassRoomEntity classRoomEntity=classRoomRepository.findById(createClassStudentDto.getClassRoomId()).orElse(null);
        responseClassStudentDto.setClassRoomId(classRoomEntity.getId());
        return new ResponseEntity<>(responseClassStudentDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-classStudent", method = RequestMethod.GET)
    public ResponseEntity<List< ClassStudentDto>> getAllClassStudent() {
        List< ClassStudentDto>  ClassStudentDtoList =  classStudentService.getClassStudents();
        return new ResponseEntity<>( ClassStudentDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{classStudentId}", method = RequestMethod.GET)
    public ResponseEntity<ClassStudentDto> getClassStudent( @PathVariable(value="classStudentId")Long classStudentId) {
        ClassStudentDto responseClassStudentDto = null;
        try {
            responseClassStudentDto =  classStudentService.getClassStudentById(classStudentId);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseClassStudentDto, HttpStatus.OK);
    }
}

