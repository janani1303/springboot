package com.example.database.services.impl;
import com.example.database.dtos.SubjectDto;
import com.example.database.entities.SubjectEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.SubjectMapper;
import com.example.database.repositories.SubjectRepository;
import com.example.database.services.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SubjectServiceImpl implements SubjectService {
    @Autowired
    SubjectRepository subjectRepository;


    @Override
    public SubjectDto addSubject(SubjectDto subjectDto) throws ResourceExist {
        SubjectEntity entity = subjectRepository.getSubjectByName(subjectDto.getName());
        if (entity != null)
            throw new ResourceExist("Subject name exist");
        entity = SubjectMapper.INSTANCE.toEntity(subjectDto);
        entity = subjectRepository.save(entity);
        return SubjectMapper.INSTANCE.toDto(entity);
    }


    @Override
    public SubjectDto getSubjectByName(String name) throws ResourceNotFound {
        return Optional.ofNullable(subjectRepository
                .getSubjectByName(name))
                .map(SubjectMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Subject not found"));
    }

    @Override
    public List<SubjectDto> getSubjects() {
        return Optional.ofNullable(subjectRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(SubjectMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
//    @Override
//    public StudentDto updateStudent(StudentDto studentDto) throws ResourceExist {
//        StudentEntity entity = studentRepository.getStudentEntityById(studentDto.getId());
//        System.out.println(entity.getId());
//        System.out.println(entity.getName());
//        System.out.println(entity.getDateOfBirth());
//        entity.setName(studentDto.getName());
//        entity.setDateOfBirth(studentDto.getDateOFBirth());
//        entity = studentRepository.save(entity);
//        return StudentMapper.INSTANCE.toDto(entity);
//    }


}

