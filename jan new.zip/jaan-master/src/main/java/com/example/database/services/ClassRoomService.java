package com.example.database.services;

import com.example.database.dtos.ClassRoomDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;



public interface  ClassRoomService {

    ClassRoomDto addClassRoom(ClassRoomDto classRoomDto) throws ResourceExist;

    ClassRoomDto getClassRoomById(Long id) throws ResourceNotFound;

    List<ClassRoomDto> getClassRooms();

    //GradeDto updateGrade( GradeDto gradeDto) throws ResourceExist;

//    void deleteById(Long id);
//
//    void deleteAll();
}