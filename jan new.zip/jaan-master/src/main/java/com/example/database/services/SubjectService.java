package com.example.database.services;

import com.example.database.dtos.StudentDto;
import com.example.database.dtos.SubjectDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface SubjectService {
    SubjectDto addSubject(SubjectDto subjectDto) throws ResourceExist;

    SubjectDto getSubjectByName(String name) throws ResourceNotFound;

    List<SubjectDto> getSubjects();

//    StudentDto updateStudent( StudentDto studentDto) throws ResourceExist;
//
//    void deleteById(Long id);
//
//    void deleteAll();
}
