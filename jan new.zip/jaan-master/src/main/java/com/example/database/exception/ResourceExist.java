package com.example.database.exception;

public class ResourceExist extends RuntimeException {
    public ResourceExist(String msg) {
        super(msg);
    }
}


