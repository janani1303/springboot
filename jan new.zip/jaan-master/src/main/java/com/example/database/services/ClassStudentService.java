package com.example.database.services;

import com.example.database.dtos.ClassStudentDto;
import com.example.database.dtos.GradeDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface ClassStudentService
{
    ClassStudentDto addClassStudent(ClassStudentDto classStudentDto) throws ResourceExist;

    ClassStudentDto getClassStudentById(Long id) throws ResourceNotFound;

    List<ClassStudentDto> getClassStudents();
}
