package com.example.database.controllers;

import com.example.database.dtos.ClassRoomDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.entities.GradeEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.repositories.GradeRepository;
import com.example.database.services.ClassRoomService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/classRoom")
public class ClassRoomController {

    private static final Logger LOGGER = LoggerFactory.getLogger( ClassRoomController.class);

    @Autowired
    GradeRepository gradeRepository;
    @Autowired
    ClassRoomService classRoomService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-classroom", method = RequestMethod.POST)
    public ResponseEntity<ClassRoomDto> addClassRoom(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class}) ClassRoomDto createClassRoomDto) {
        System.out.println("The grade id is"+createClassRoomDto.getGradeId());
        ClassRoomDto responseClassRoomDto = null;

        try {
            responseClassRoomDto =  classRoomService. addClassRoom(createClassRoomDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }

        GradeEntity gradeEntity=gradeRepository.findById(createClassRoomDto.getGradeId()).orElse(null);
        responseClassRoomDto.setGradeId(gradeEntity.getId());
        return new ResponseEntity<>(responseClassRoomDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-classroom", method = RequestMethod.GET)
    public ResponseEntity<List< ClassRoomDto>> getAllClassRoom() {
        List< ClassRoomDto>  ClassRoomDtoList =  classRoomService.getClassRooms();
        return new ResponseEntity<>(ClassRoomDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{classroomId}", method = RequestMethod.GET)
    public ResponseEntity<ClassRoomDto> getClassRoom( @PathVariable(value="classroomId")Long classroomId) {
        ClassRoomDto responseClassRoomDto = null;
        try {
            responseClassRoomDto = classRoomService.getClassRoomById(classroomId);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseClassRoomDto, HttpStatus.OK);
    }


//    @RequestMapping(value = "/update-grade", method = RequestMethod.PUT)
//    public ResponseEntity<GradeDto> updateGrade(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})GradeDto updateGradeDto) {
//        GradeDto responseGradeDto = null;
//        try {
//            responseGradeDto =  gradeService.updateGrade(updateGradeDto);
//        } catch (ResourceExist e) {
//            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
//        }
//        TeacherEntity teacherEntity=teacherRepository.findById(updateGradeDto.getTeacherId()).orElse(null);
//        responseGradeDto.setTeacherId(teacherEntity.getId());
//        return new ResponseEntity<>(responseGradeDto, HttpStatus.OK);
//    }


}