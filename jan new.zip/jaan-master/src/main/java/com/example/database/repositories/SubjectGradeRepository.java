package com.example.database.repositories;

import com.example.database.entities.ClassStudentEntity;
import com.example.database.entities.StudentEntity;
import com.example.database.entities.SubjectGradeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubjectGradeRepository extends JpaRepository<StudentEntity,Long>
{
    @Query(value = "select * from subject_grade where id =:inpId",nativeQuery = true)
    SubjectGradeEntity getSubjectGradeById(@Param("inpId") Long id);

//    @Query(value = "select * from Student where name =:name",nativeQuery = true)
//    StudentEntity getStudentByName(@Param("name") String name);

    SubjectGradeEntity getSubjectGradeEntityById(Long Id);

    //ClassStudentEntity findByStudentName(String studentName);

}

