package com.example.database.services;


import com.example.database.dtos.ResultDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface ResultService
{
    ResultDto addResult(ResultDto resultDto) throws ResourceExist;

    ResultDto getResultById(Long id) throws ResourceNotFound;

    List<ResultDto> getResults();
}
