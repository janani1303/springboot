package com.example.database.services;
import com.example.database.dtos.StudentDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import java.util.List;


public interface  StudentService {

    StudentDto addStudent(StudentDto studentDto) throws ResourceExist;

    StudentDto getStudentByName(String name) throws ResourceNotFound;

    List<StudentDto> getStudents();

    StudentDto updateStudent( StudentDto studentDto) throws ResourceExist;

    void deleteById(Long id);

    void deleteAll();
}