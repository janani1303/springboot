package com.example.database.repositories.impl;

import com.example.database.entities.AttendanceEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class AttendanceRepositoryImpl{
    @PersistenceContext
    private EntityManager entityManager;

    public AttendanceEntity findByAttendanceId(Long id) {
        Query query = entityManager.createNativeQuery("select * from attendance where id = " + id, AttendanceEntity.class);
        return (AttendanceEntity)  query.getSingleResult();
    }

}