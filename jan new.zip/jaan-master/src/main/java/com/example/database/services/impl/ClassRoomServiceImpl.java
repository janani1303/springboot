package com.example.database.services.impl;

import com.example.database.dtos.ClassRoomDto;
import com.example.database.dtos.GradeDto;
import com.example.database.entities.ClassRoomEntity;
import com.example.database.entities.GradeEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.ClassRoomMapper;
import com.example.database.mappers.GradeMapper;
import com.example.database.repositories.ClassRoomRepository;
import com.example.database.repositories.GradeRepository;
import com.example.database.services.ClassRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class ClassRoomServiceImpl implements ClassRoomService {

    @Autowired
    ClassRoomRepository classRoomRepository;

    @Autowired
    GradeRepository gradeRepository;

    @Override
    public ClassRoomDto addClassRoom(ClassRoomDto classRoomDto) throws ResourceExist {
        System.out.println(classRoomDto.getGradeId());
        ClassRoomEntity classRoomEntity = classRoomRepository.getClassRoomById(classRoomDto.getId());
        if (classRoomEntity != null)
            throw new ResourceExist("ClassRoom exist");

        GradeEntity gradeEntity = gradeRepository.findById(classRoomDto.getGradeId()).orElse(null);
        if(gradeEntity ==null)
            throw new ResourceNotFound("No such grade exists");

        classRoomEntity = ClassRoomMapper.INSTANCE.toEntity(classRoomDto);
        classRoomEntity.setGradeEntity(gradeEntity);
        classRoomEntity = classRoomRepository.save(classRoomEntity);
        return ClassRoomMapper.INSTANCE.toDto(classRoomEntity);
    }

    @Override
    public ClassRoomDto getClassRoomById(Long id) throws ResourceNotFound {
        return Optional.ofNullable(classRoomRepository
                .getClassRoomById(id))
                .map(ClassRoomMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("ClassRoom not found"));
    }
    @Override
    public List<ClassRoomDto> getClassRooms() {
        return Optional.ofNullable(classRoomRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(ClassRoomMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
//    @Override
//    public GradeDto updateGrade(GradeDto gradeDto) throws ResourceExist {
//        GradeEntity gradeEntity = gradeRepository.getGradeEntityById(gradeDto.getId());
//        if(gradeEntity==null)
//            throw new ResourceNotFound("No such grade exists");
//
//        TeacherEntity teacherEntity = teacherRepository.findById(gradeDto.getTeacherId()).orElse(null);
//        if(teacherEntity==null)
//            throw new ResourceNotFound("No such teacher exists");
//
//        gradeEntity = GradeMapper.INSTANCE.toEntity(gradeDto);
//        gradeEntity.setTeacherEntity(teacherEntity);
//        gradeEntity = gradeRepository.save(gradeEntity);
//
//
//        return GradeMapper.INSTANCE.toDto(gradeEntity);
//    }

}
