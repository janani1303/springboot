package com.example.database.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
@Entity
@Table(name = "result")
@Getter
@Setter
public class ResultEntity extends AuditEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "student_id")
    private StudentEntity studentEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "subject_id")
    private SubjectEntity subjectEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "term_id")
    private TermEntity termEntity;

    @Column(name = "marks")
    private Long marks;
}
