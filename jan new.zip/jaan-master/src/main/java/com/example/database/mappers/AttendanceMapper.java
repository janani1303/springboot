package com.example.database.mappers;

import com.example.database.dtos.AttendanceDto;
import com.example.database.dtos.GradeDto;
import com.example.database.entities.AttendanceEntity;
import com.example.database.entities.GradeEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;



@Mapper
public interface AttendanceMapper {
    AttendanceMapper INSTANCE = Mappers.getMapper(AttendanceMapper .class);
    AttendanceEntity toEntity(AttendanceDto attendanceDto);
    AttendanceDto toDto(AttendanceEntity  attendanceEntity);
}
