package com.example.database.dtos;

import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
@Getter
@Setter
public class ResultDto
{
    @JsonView({UserView.Read.class, UserView.Update.class })
    @NotBlank(message = "id cannot be null",groups = {UserValidator.Update.class})
    private  Long id;

    @JsonView({UserView.Create.class , UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "StudentId cannot be null",groups = {UserValidator.Create.class})
    private Long studentId;


    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = " SubjectId cannot be null",groups = {UserValidator.Create.class})
    private Long subjectId;

    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = " TermId cannot be null",groups = {UserValidator.Create.class})
    private Long termId;

    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = " Marks cannot be null",groups = {UserValidator.Create.class})
    private Long marks;

}
