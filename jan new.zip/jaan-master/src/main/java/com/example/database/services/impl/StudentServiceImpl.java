package com.example.database.services.impl;

import com.example.database.dtos.StudentDto;
import com.example.database.entities.StudentEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.StudentMapper;
import com.example.database.repositories.StudentRepository;
import com.example.database.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    StudentRepository studentRepository;


    @Override
    public StudentDto addStudent(StudentDto studentDto) throws ResourceExist {
        StudentEntity entity = studentRepository.getStudentByName(studentDto.getName());
        if (entity != null)
            throw new ResourceExist("Student name exist");
        entity = StudentMapper.INSTANCE.toEntity(studentDto);
        entity = studentRepository.save(entity);

        return StudentMapper.INSTANCE.toDto(entity);
    }


    @Override
    public StudentDto getStudentByName(String name) throws ResourceNotFound {
        return Optional.ofNullable(studentRepository
                .getStudentByName(name))
                .map(StudentMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Student not found"));
    }

    @Override
    public List<StudentDto> getStudents() {
        return Optional.ofNullable(studentRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(StudentMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
    @Override
    public StudentDto updateStudent(StudentDto studentDto) throws ResourceExist {
        StudentEntity entity = studentRepository.getStudentEntityById(studentDto.getId());
        System.out.println(entity.getId());
        System.out.println(entity.getName());
        System.out.println(entity.getDateOfBirth());
        entity.setName(studentDto.getName());
        entity.setDateOfBirth(studentDto.getDateOFBirth());
        entity = studentRepository.save(entity);
        return StudentMapper.INSTANCE.toDto(entity);
    }


    @Override
    public void deleteById(Long id) {
        studentRepository.deleteById(id);
    }

    @Override
    public void deleteAll(){
        studentRepository.deleteAll();
    }


}

