package com.example.database.repositories.impl;

import com.example.database.entities.ClassRoomEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


public class ClassRoomRepositoryImpl{
    @PersistenceContext
    private EntityManager entityManager;

    public ClassRoomEntity findByClassRoomId(long id) {
        Query query = entityManager.createNativeQuery("select * from classroom where id = " + id, ClassRoomEntity.class);
        return (ClassRoomEntity)  query.getSingleResult();
    }

}