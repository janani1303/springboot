package com.example.database.mappers;

import com.example.database.dtos.TeacherDto;
import com.example.database.entities.TeacherEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


@Mapper
public interface TeacherMapper {
    TeacherMapper INSTANCE = Mappers.getMapper( TeacherMapper .class);

    TeacherEntity toEntity(TeacherDto teacherDto);
    TeacherDto toDto( TeacherEntity  teacherEntity);
}
