package com.example.database.mappers;


import com.example.database.dtos.TermDto;
import com.example.database.entities.TermEntity;
import org.mapstruct.factory.Mappers;

public interface TermMapper
{
    TermMapper INSTANCE = Mappers.getMapper( TermMapper .class);

    TermEntity toEntity(TermDto termDto);
    TermDto toDto(TermEntity  termEntity);
}
