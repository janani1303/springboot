package com.example.database.repositories;

import com.example.database.entities.ClassRoomEntity;
import com.example.database.entities.GradeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClassRoomRepository extends JpaRepository<ClassRoomEntity,Long>
{
    @Query(value = "select * from classroom where id =:inpId",nativeQuery = true)
    ClassRoomEntity getClassRoomById(@Param("inpId") Long id);

    @Query(value = "select * from classroom where grade_id =:inpId",nativeQuery = true)
    ClassRoomEntity getClassRoomByGradeId(@Param("inpId") Long id);

    @Query(value = "select * from classroom where section =:name",nativeQuery = true)
    ClassRoomEntity getClassRoomBySection(@Param("name") Character name);

    GradeEntity getGradeEntityById(Long Id);

    GradeEntity findByClassRoomId(Long classRoomId);
}