package com.example.database.controllers;

import com.example.database.dtos.TermDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.services.TermService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/term")
public class TermController {

    private static final Logger LOGGER = LoggerFactory.getLogger( TermController.class);

    @Autowired
    TermService termService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-term", method = RequestMethod.POST)
    public ResponseEntity<TermDto> addTerm(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  TermDto createTermDto) {

        TermDto responseTermDto = null;
        try {
            responseTermDto =  termService. addTerm(createTermDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        return new ResponseEntity<>(responseTermDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-term", method = RequestMethod.GET)
    public ResponseEntity<List< TermDto>> getAllTerm() {
        List< TermDto>  TermDtoList =  termService.getTerms();
        return new ResponseEntity<>( TermDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{termName}", method = RequestMethod.GET)
    public ResponseEntity<TermDto> getTerm( @PathVariable(value="termName")String termName) {
        TermDto responseTermDto = null;
        try {
            responseTermDto =  termService.getTermByName(termName);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseTermDto, HttpStatus.OK);
    }


//    @RequestMapping(value = "/update-student", method = RequestMethod.PUT)
//    public ResponseEntity<StudentDto> updateStudent(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})StudentDto updateStudentDto) {
//        StudentDto responseStudentDto = null;
//        try {
//            responseStudentDto =  studentService.updateStudent(updateStudentDto);
//        } catch (ResourceExist e) {
//            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
//        }
//        return new ResponseEntity<>(responseStudentDto, HttpStatus.OK);
//    }
//
//    @RequestMapping(value = "/delete-student/{id}", method = RequestMethod.DELETE)
//    public String delete(@PathVariable Long id) {
//        studentService.deleteById(id);
//        return "Deleted";
//    }
//
//    @RequestMapping(value = "/delete-student", method = RequestMethod.DELETE)
//    public String deleteAll() {
//        studentService.deleteAll();
//        return "Deleted";
//    }



}