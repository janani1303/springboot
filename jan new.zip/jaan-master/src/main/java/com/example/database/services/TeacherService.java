package com.example.database.services;

import com.example.database.dtos.TeacherDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;


public interface TeacherService {

    TeacherDto addTeacher(TeacherDto teacherDto) throws ResourceExist;

    TeacherDto getTeacherByName(String name) throws ResourceNotFound;

    List<TeacherDto> getTeachers();

    TeacherDto updateTeacher(TeacherDto teacherDto) throws ResourceExist;

    void deleteById(Long id);

    void deleteAll();
}

