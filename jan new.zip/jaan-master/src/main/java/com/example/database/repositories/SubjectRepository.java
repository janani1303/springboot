package com.example.database.repositories;

import com.example.database.entities.SubjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubjectRepository extends JpaRepository<SubjectEntity,Long>
{
    @Query(value = "select * from subject where id =:inpId",nativeQuery = true)
    SubjectEntity getSubjectById(@Param("inpId") Long id);

    @Query(value = "select * from subject where name =:name",nativeQuery = true)
    SubjectEntity getSubjectByName(@Param("name") String name);

    SubjectEntity getSubjectEntityById(Long Id);

    SubjectEntity findBySubjectName(String subjectName);
}

