package com.example.database.services.impl;


import com.example.database.dtos.TermDto;
import com.example.database.entities.TermEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.TermMapper;
import com.example.database.repositories.TermRepository;
import com.example.database.services.TermService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class TermServiceImpl implements TermService {
    @Autowired
    TermRepository termRepository;


    @Override
    public TermDto addTerm(TermDto termDto) throws ResourceExist {
        TermEntity entity = termRepository.getTermByName(termDto.getName());
        if (entity != null)
            throw new ResourceExist("Term name exist");
        entity = TermMapper.INSTANCE.toEntity(termDto);
        entity = termRepository.save(entity);
        return TermMapper.INSTANCE.toDto(entity);
    }


    @Override
    public TermDto getTermByName(String name) throws ResourceNotFound {
        return Optional.ofNullable(termRepository
                .getTermByName(name))
                .map(TermMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Term not found"));
    }

    @Override
    public List<TermDto> getTerms() {
        return Optional.ofNullable(termRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(TermMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
}
