package com.example.database.dtos.filters;

public class UserView extends BaseView {
}
