package com.example.database.dtos;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Getter;
import lombok.Setter;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class TeacherDto
{

    @JsonView({UserView.Read.class, UserView.Update.class })
    @NotBlank(message = "id cannot be null",groups = {UserValidator.Update.class})
    private  Long id;

    @JsonView({UserView.Create.class , UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "Name cannot be null",groups = {UserValidator.Create.class})
    private String name;


    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "Email  cannot be null",groups = {UserValidator.Create.class})
    private String email;


    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "Password  cannot be null",groups = {UserValidator.Create.class})
    private String password;


    @JsonView({UserView.Create.class ,UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "PhoneNumber cannot be null",groups = {UserValidator.Create.class})
    private Long phone_number;
}
