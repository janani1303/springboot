package com.example.database.dtos.filters;

public class BaseView {
    public static class Create{}
    public static class Update{}
    public static class Read{}

}
