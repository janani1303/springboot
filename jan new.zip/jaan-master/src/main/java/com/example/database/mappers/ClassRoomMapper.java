package com.example.database.mappers;

import com.example.database.dtos.ClassRoomDto;
import com.example.database.entities.ClassRoomEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ClassRoomMapper {
    ClassRoomMapper INSTANCE = Mappers.getMapper(ClassRoomMapper .class);

    ClassRoomEntity toEntity(ClassRoomDto classRoomDto);
    ClassRoomDto toDto( ClassRoomEntity  classRoomEntity);
}