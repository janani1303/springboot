package com.example.database.exception;

public class ResourceDenied extends RuntimeException {
    public ResourceDenied(String msg) {
        super(msg);
    }
}