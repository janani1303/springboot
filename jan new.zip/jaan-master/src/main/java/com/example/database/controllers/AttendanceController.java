package com.example.database.controllers;

import com.example.database.dtos.AttendanceDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.entities.StudentEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.repositories.AttendanceRepository;
import com.example.database.repositories.StudentRepository;
import com.example.database.services.AttendanceService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/attendance")
public class AttendanceController {

    private static final Logger LOGGER = LoggerFactory.getLogger( AttendanceController.class);

    @Autowired
    StudentRepository studentRepository;
    @Autowired
    AttendanceService attendanceService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-attendance", method = RequestMethod.POST)
    public ResponseEntity<AttendanceDto> addAttendance(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  AttendanceDto createAttendanceDto) {
        System.out.println("The student id is"+createAttendanceDto.getStudentId());
        AttendanceDto responseAttendanceDto = null;

        try {
            responseAttendanceDto =  attendanceService. addAttendance(createAttendanceDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }

        StudentEntity studentEntity=studentRepository.findById(createAttendanceDto.getStudentId()).orElse(null);
        responseAttendanceDto.setStudentId(studentEntity.getId());
        return new ResponseEntity<>(responseAttendanceDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-attendance", method = RequestMethod.GET)
    public ResponseEntity<List< AttendanceDto>> getAllAttendance() {
        List< AttendanceDto>  AttendanceDtoList =  attendanceService.getAttendances();
        return new ResponseEntity<>(AttendanceDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{attendanceId}", method = RequestMethod.GET)
    public ResponseEntity<AttendanceDto> getAttendance( @PathVariable(value="attendanceId")Long attendanceId) {
        AttendanceDto responseAttendanceDto = null;
        try {
            responseAttendanceDto = attendanceService.getAttendanceById(attendanceId);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseAttendanceDto, HttpStatus.OK);
    }


    @RequestMapping(value = "/update-attendance", method = RequestMethod.PUT)
    public ResponseEntity<AttendanceDto> updateAttendance(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})AttendanceDto updateAttendanceDto) {
        AttendanceDto responseAttendanceDto = null;
        try {
            responseAttendanceDto =  attendanceService.updateAttendance(updateAttendanceDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        StudentEntity studentEntity=studentRepository.findById(updateAttendanceDto.getStudentId()).orElse(null);
        responseAttendanceDto.setStudentId(studentEntity.getId());
        return new ResponseEntity<>(responseAttendanceDto, HttpStatus.OK);
    }
    }

//    @RequestMapping(value = "/delete-teacher/{id}", method = RequestMethod.DELETE)
//    public String delete(@PathVariable Long id) {
//        teacherService.deleteById(id);
//        return "Deleted";
//    }
//
//    @RequestMapping(value = "/delete-teacher", method = RequestMethod.DELETE)
//    public String deleteAll() {
//        teacherService.deleteAll();
//        return "Deleted";
//    }
