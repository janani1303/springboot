package com.example.database.controllers;

import com.example.database.dtos.SubjectGradeDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.entities.GradeEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.repositories.GradeRepository;
import com.example.database.services.SubjectGradeService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
@RestController
@RequestMapping(value = "/api/v1/subjectGrade")
public class SubjectGradeController
{
    private static final Logger LOGGER = LoggerFactory.getLogger( SubjectGradeController.class);

    @Autowired
    GradeRepository gradeRepository;
    @Autowired
    SubjectGradeService subjectGradeService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-subjectGrade", method = RequestMethod.POST)
    public ResponseEntity<SubjectGradeDto> addSubjectGrade(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class}) SubjectGradeDto createSubjectGradeDto) {

        SubjectGradeDto responseSubjectGradeDto = null;
        try {
            responseSubjectGradeDto =  subjectGradeService. addSubjectGrade(createSubjectGradeDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }

        GradeEntity gradeEntity=gradeRepository.findById(createSubjectGradeDto.getGradeId()).orElse(null);
        responseSubjectGradeDto.setGradeId(gradeEntity.getId());
        return new ResponseEntity<>(responseSubjectGradeDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-subjectGrade", method = RequestMethod.GET)
    public ResponseEntity<List< SubjectGradeDto>> getAllSubjectGrade() {
        List< SubjectGradeDto>  SubjectGradeDtoList =  SubjectGradeService.getSubjectGrades();
        return new ResponseEntity<>( SubjectGradeDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{subjectGradeId}", method = RequestMethod.GET)
    public ResponseEntity<SubjectGradeDto> getSubjectGrade( @PathVariable(value="subjectGradeId")Long subjectGradeId) {
        SubjectGradeDto responseSubjectGradeDto = null;
        try {
            responseSubjectGradeDto =  subjectGradeService.getSubjectGradeById(subjectGradeId);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseSubjectGradeDto, HttpStatus.OK);
    }
}
