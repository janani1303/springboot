package com.example.database.repositories.impl;

import com.example.database.entities.GradeEntity;
import com.example.database.entities.TeacherEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class GradeRepositoryImpl{
    @PersistenceContext
    private EntityManager entityManager;

    public GradeEntity findByGradeName(String name) {
        Query query = entityManager.createNativeQuery("select * from grade where name = " + name, GradeEntity.class);
        return (GradeEntity)  query.getSingleResult();
    }

}