package com.example.database.repositories;
import com.example.database.entities.GradeEntity;
import com.example.database.entities.TeacherEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface GradeRepository extends JpaRepository<GradeEntity,Long>
{
    @Query(value = "select * from grade where id =:inpId",nativeQuery = true)
    GradeEntity getGradeById(@Param("inpId") Long id);

    @Query(value = "select * from grade where name =:name",nativeQuery = true)
    GradeEntity getGradeByName(@Param("name") String name);

    @Query(value = "select * from grade where teacher_id =:inpId",nativeQuery = true)
    GradeEntity getGradeByTeacherId(@Param("inpId") Long id);

    GradeEntity getGradeEntityById(Long Id);

    GradeEntity findByGradeName(String gradeName);
}
