package com.example.database.services.impl;

import com.example.database.dtos.SubjectGradeDto;
import com.example.database.entities.GradeEntity;
import com.example.database.entities.SubjectGradeEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.SubjectGradeMapper;
import com.example.database.repositories.GradeRepository;
import com.example.database.repositories.SubjectGradeRepository;
import com.example.database.services.SubjectGradeService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SubjectGradeServiceImpl implements SubjectGradeService
{
    @Autowired
    SubjectGradeRepository subjectGradeRepository;

    @Autowired
    GradeRepository gradeRepository;

    @Override
    public SubjectGradeDto addSubjectGrade(SubjectGradeDto subjectGradeDto) throws ResourceExist {
        System.out.println(subjectGradeDto.getGradeId());
        SubjectGradeEntity subjectGradeEntity = subjectGradeRepository.getSubjectGradeById(subjectGradeDto.getId());
        if (subjectGradeEntity != null)
            throw new ResourceExist("SubjectGrade exist");

        GradeEntity gradeEntity = gradeRepository.findById(subjectGradeDto.getGradeId()).orElse(null);
        if(subjectGradeEntity ==null)
            throw new ResourceNotFound("No such grade exists");

        subjectGradeEntity =SubjectGradeMapper.INSTANCE.toEntity(subjectGradeDto);
        subjectGradeEntity.setGradeEntity(gradeEntity);
        subjectGradeEntity = subjectGradeRepository.save(subjectGradeEntity);
        return SubjectGradeMapper.INSTANCE.toDto(subjectGradeEntity);
    }

    @Override
    public SubjectGradeDto getSubjectGradeById(Long id) throws ResourceNotFound {
        return Optional.ofNullable(subjectGradeRepository
                .getSubjectGradeById(id))
                .map(SubjectGradeMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("SubjectGrade not found"));
    }
    @Override
    public List<SubjectGradeDto> getSubjectGrades() {
        return Optional.ofNullable(subjectGradeRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(SubjectGradeMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
}
