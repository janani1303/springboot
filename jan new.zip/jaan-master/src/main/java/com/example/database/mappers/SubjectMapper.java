package com.example.database.mappers;

import com.example.database.dtos.SubjectDto;
import com.example.database.entities.SubjectEntity;
import org.mapstruct.factory.Mappers;

public interface SubjectMapper {
    SubjectMapper INSTANCE = Mappers.getMapper(SubjectMapper .class);

    SubjectEntity toEntity(SubjectDto subjectDto);
    SubjectDto toDto(SubjectEntity  subjectEntity);
}
