package com.example.database.repositories;

import com.example.database.entities.TeacherEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;



@Repository
public interface TeacherRepository extends JpaRepository<TeacherEntity,Long>
{
    @Query(value = "select * from teacher where id =:inpId",nativeQuery = true)
    TeacherEntity getTeacherById(@Param("inpId") Long id);

    @Query(value = "select * from teacher where name =:name",nativeQuery = true)
    TeacherEntity getTeacherByName(@Param("name") String name);

    TeacherEntity getTeacherEntityById(Long Id);

    TeacherEntity findByTeacherName(String teacherName);
}
