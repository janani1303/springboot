package com.example.database.entities;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;


@Entity
@Table(name = "grade")
@Getter
@Setter
public class GradeEntity extends AuditEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "teacher_id")
    private TeacherEntity teacherEntity;


}
