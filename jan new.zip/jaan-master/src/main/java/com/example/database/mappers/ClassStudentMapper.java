package com.example.database.mappers;

import com.example.database.dtos.ClassStudentDto;
import com.example.database.entities.ClassStudentEntity;
import org.mapstruct.factory.Mappers;

public interface ClassStudentMapper
{
    ClassStudentMapper INSTANCE = Mappers.getMapper(ClassStudentMapper .class);

    ClassStudentEntity toEntity(ClassStudentDto classStudentDto);
    ClassStudentDto toDto( ClassStudentEntity  classStudentEntity);
}
