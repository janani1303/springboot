package com.example.database.repositories;

import com.example.database.entities.SubjectEntity;
import com.example.database.entities.TermEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TermRepository extends JpaRepository<TermEntity,Long>
{
    @Query(value = "select * from term where id =:inpId",nativeQuery = true)
    TermEntity getTermById(@Param("inpId") Long id);

    @Query(value = "select * from term where name =:name",nativeQuery = true)
    TermEntity getTermByName(@Param("name") String name);

    TermEntity getTermEntityById(Long Id);

    TermEntity findByTermName(String termName);
}

