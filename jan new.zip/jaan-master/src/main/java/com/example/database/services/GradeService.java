package com.example.database.services;
import com.example.database.dtos.GradeDto;
import com.example.database.dtos.TeacherDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import java.util.List;


public interface  GradeService {

    GradeDto addGrade( GradeDto gradeDto) throws ResourceExist;

    GradeDto getGradeByName(String name) throws ResourceNotFound;

    List<GradeDto> getGrades();

    GradeDto updateGrade( GradeDto gradeDto) throws ResourceExist;

//    void deleteById(Long id);
//
//    void deleteAll();
}
