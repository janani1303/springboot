package com.example.database.repositories.impl;

import com.example.database.entities.TeacherEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


public class TeacherRepositoryImpl{
    @PersistenceContext
    private EntityManager entityManager;

    public TeacherEntity findByTeacherName(String name) {
        Query query = entityManager.createNativeQuery("select * from teacher where name = " + name, TeacherEntity.class);
        return (TeacherEntity)  query.getSingleResult();
    }

}
