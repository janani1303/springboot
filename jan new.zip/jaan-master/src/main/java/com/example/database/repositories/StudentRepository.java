package com.example.database.repositories;
import com.example.database.entities.StudentEntity;
import com.example.database.entities.TeacherEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface StudentRepository extends JpaRepository<StudentEntity,Long>
{
    @Query(value = "select * from student where id =:inpId",nativeQuery = true)
    StudentEntity getStudentById(@Param("inpId") Long id);

    @Query(value = "select * from Student where name =:name",nativeQuery = true)
    StudentEntity getStudentByName(@Param("name") String name);

    StudentEntity getStudentEntityById(Long Id);

    StudentEntity findByStudentName(String studentName);
}
