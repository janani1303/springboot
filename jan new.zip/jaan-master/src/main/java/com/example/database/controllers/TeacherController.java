package com.example.database.controllers;

import com.example.database.dtos.TeacherDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.services.TeacherService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/teacher")
public class TeacherController {

    private static final Logger LOGGER = LoggerFactory.getLogger( TeacherController.class);

    @Autowired
    TeacherService teacherService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-teacher", method = RequestMethod.POST)
    public ResponseEntity<TeacherDto> addTeacher(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  TeacherDto createTeacherDto) {

        TeacherDto responseTeacherDto = null;
        try {
            responseTeacherDto =  teacherService. addTeacher(createTeacherDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        return new ResponseEntity<>(responseTeacherDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-teacher", method = RequestMethod.GET)
    public ResponseEntity<List< TeacherDto>> getAllTeacher() {
        List< TeacherDto>  TeacherDtoList =  teacherService.getTeachers();
        return new ResponseEntity<>( TeacherDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{teacherName}", method = RequestMethod.GET)
    public ResponseEntity<TeacherDto> getTeacher( @PathVariable(value="teacherName")String teacherName) {
        TeacherDto responseTeacherDto = null;
        try {
            responseTeacherDto =  teacherService.getTeacherByName(teacherName);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseTeacherDto, HttpStatus.OK);
    }


    @RequestMapping(value = "/update-teacher", method = RequestMethod.PUT)
    public ResponseEntity<TeacherDto> updateTeacher(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})TeacherDto updateTeacherDto) {
        TeacherDto responseTeacherDto = null;
        try {
            responseTeacherDto =  teacherService.updateTeacher(updateTeacherDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        return new ResponseEntity<>(responseTeacherDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/delete-teacher/{id}", method = RequestMethod.DELETE)
    public String delete(@PathVariable Long id) {
        teacherService.deleteById(id);
        return "Deleted";
    }

    @RequestMapping(value = "/delete-teacher", method = RequestMethod.DELETE)
    public String deleteAll() {
        teacherService.deleteAll();
        return "Deleted";
    }



}