package com.example.database.repositories;

import com.example.database.entities.AttendanceEntity;
import com.example.database.entities.GradeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AttendanceRepository extends JpaRepository<AttendanceEntity,Long>
{
    @Query(value = "select * from attendance where id =:inpId",nativeQuery = true)
    AttendanceEntity getAttendanceById(@Param("inpId") Long id);

//    @Query(value = "select * from attendance where name =:name",nativeQuery = true)
//    AttendanceEntity getAttendanceByName(@Param("name") String name);

    @Query(value = "select * from attendance where student_id =:inpId",nativeQuery = true)
    AttendanceEntity getAttendanceByTeacherId(@Param("inpId") Long id);

    AttendanceEntity getAttendanceEntityById(Long Id);


    //AttendanceEntity findByAttendanceName(String attendanceName);
}
