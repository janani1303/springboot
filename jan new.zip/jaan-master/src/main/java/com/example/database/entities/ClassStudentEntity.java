package com.example.database.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "class_student")
@Getter
@Setter
public class ClassStudentEntity extends AuditEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "classroom_id")
    private ClassRoomEntity classRoomEntity;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name= "student_id")
    private StudentEntity studentEntity;

}
