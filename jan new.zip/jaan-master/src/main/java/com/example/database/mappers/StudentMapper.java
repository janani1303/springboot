package com.example.database.mappers;
import com.example.database.dtos.StudentDto;
import com.example.database.entities.StudentEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface StudentMapper {
    StudentMapper INSTANCE = Mappers.getMapper( StudentMapper .class);

    StudentEntity toEntity(StudentDto studentDto);
    StudentDto toDto( StudentEntity  studentEntity);
}
