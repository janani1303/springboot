package com.example.database.mappers;

import com.example.database.dtos.ResultDto;
import com.example.database.entities.ResultEntity;
import org.mapstruct.factory.Mappers;

public interface ResultMapper {
    ResultMapper INSTANCE = Mappers.getMapper(ResultMapper .class);

    ResultEntity toEntity(ResultDto resultDto);
    ResultDto toDto( ResultEntity  resultEntity);
}
