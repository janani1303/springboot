package com.example.database.repositories.impl;

import com.example.database.entities.SubjectEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class SubjectRepositoryImpl
{
    @PersistenceContext
    private EntityManager entityManager;

    public SubjectEntity findBySubjectName(String name) {
        Query query = entityManager.createNativeQuery("select * from subject where name = " + name, SubjectEntity.class);
        return (SubjectEntity)  query.getSingleResult();
    }
}
