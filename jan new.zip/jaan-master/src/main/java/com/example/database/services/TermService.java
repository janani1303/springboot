package com.example.database.services;

import com.example.database.dtos.TermDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface TermService {
    TermDto addTerm(TermDto termDto) throws ResourceExist;

    TermDto getTermByName(String name) throws ResourceNotFound;

    List<TermDto> getTerms();
}
