package com.example.database.dtos;

import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.fasterxml.jackson.annotation.JsonView;

import javax.validation.constraints.NotBlank;

public class TermDto
{
    @JsonView({UserView.Read.class, UserView.Update.class })
    @NotBlank(message = "id cannot be null",groups = {UserValidator.Update.class})
    private  Long id;

    @JsonView({UserView.Create.class , UserView.Update.class ,UserView.Read.class})
    @NotBlank(message = "Name cannot be null",groups = {UserValidator.Create.class})
    private String name;
}
