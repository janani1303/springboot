package com.example.database.services;

import com.example.database.dtos.SubjectGradeDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface SubjectGradeService
{
    SubjectGradeDto addSubjectGrade(SubjectGradeDto subjectGradeDto) throws ResourceExist;

    SubjectGradeDto getSubjectGradeById(Long id) throws ResourceNotFound;

    static List<SubjectGradeDto> getSubjectGrades();
}
