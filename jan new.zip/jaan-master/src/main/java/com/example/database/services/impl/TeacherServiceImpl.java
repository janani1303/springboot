package com.example.database.services.impl;
import com.example.database.dtos.TeacherDto;
import com.example.database.entities.TeacherEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.TeacherMapper;
import com.example.database.repositories.TeacherRepository;
import com.example.database.services.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    TeacherRepository teacherRepository;


    @Override
    public TeacherDto addTeacher(TeacherDto teacherDto) throws ResourceExist {
        TeacherEntity entity = teacherRepository.getTeacherByName(teacherDto.getName());
        if (entity != null)
            throw new ResourceExist("Teacher name exist");
        entity = TeacherMapper.INSTANCE.toEntity(teacherDto);
        entity = teacherRepository.save(entity);

        return TeacherMapper.INSTANCE.toDto(entity);
    }


    @Override
    public TeacherDto getTeacherByName(String name) throws ResourceNotFound {
        return Optional.ofNullable(teacherRepository
                .getTeacherByName(name))
                .map(TeacherMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Teacher not found"));
    }

    @Override
    public List<TeacherDto> getTeachers() {
        return Optional.ofNullable(teacherRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(TeacherMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
    @Override
    public TeacherDto updateTeacher(TeacherDto teacherDto) throws ResourceExist {
        TeacherEntity entity = teacherRepository.getTeacherEntityById(teacherDto.getId());
        System.out.println(entity.getId());
        System.out.println(entity.getName());
        System.out.println(entity.getEmail());
        System.out.println(entity.getPassword());
        System.out.println(entity.getPhone_number());
        entity.setName(teacherDto.getName());
        entity.setEmail(teacherDto.getEmail());
        entity.setPassword(teacherDto.getPassword());
        entity.setPhone_number(teacherDto.getPhone_number());
        entity = teacherRepository.save(entity);
        return TeacherMapper.INSTANCE.toDto(entity);
    }


    @Override
    public void deleteById(Long id) {
        teacherRepository.deleteById(id);
    }

    @Override
    public void deleteAll(){
        teacherRepository.deleteAll();
    }


}

