package com.example.database.services.impl;
import com.example.database.dtos.GradeDto;
import com.example.database.dtos.TeacherDto;
import com.example.database.entities.GradeEntity;
import com.example.database.entities.TeacherEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.GradeMapper;
import com.example.database.mappers.TeacherMapper;
import com.example.database.repositories.GradeRepository;
import com.example.database.repositories.TeacherRepository;
import com.example.database.services.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class GradeServiceImpl implements GradeService {

    @Autowired
    GradeRepository gradeRepository;

    @Autowired
    TeacherRepository teacherRepository;


    @Override
    public GradeDto addGrade(GradeDto gradeDto) throws ResourceExist {
        System.out.println(gradeDto.getTeacherId());
        GradeEntity gradeEntity = gradeRepository.getGradeByName(gradeDto.getName());
        if (gradeEntity != null)
            throw new ResourceExist("Grade name exist");

        TeacherEntity teacherEntity = teacherRepository.findById(gradeDto.getTeacherId()).orElse(null);
        if(teacherEntity==null)
            throw new ResourceNotFound("No such teacher exists");

        gradeEntity = GradeMapper.INSTANCE.toEntity(gradeDto);
        gradeEntity.setTeacherEntity(teacherEntity);
        gradeEntity = gradeRepository.save(gradeEntity);
        return GradeMapper.INSTANCE.toDto(gradeEntity);
    }


    @Override
    public GradeDto getGradeByName(String name) throws ResourceNotFound {
        return Optional.ofNullable(gradeRepository
                .getGradeByName(name))
                .map(GradeMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Grade not found"));
    }

    @Override
    public List<GradeDto> getGrades() {
        return Optional.ofNullable(gradeRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(GradeMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
    @Override
    public GradeDto updateGrade(GradeDto gradeDto) throws ResourceExist {
        GradeEntity gradeEntity = gradeRepository.getGradeEntityById(gradeDto.getId());
        if(gradeEntity==null)
            throw new ResourceNotFound("No such grade exists");

        TeacherEntity teacherEntity = teacherRepository.findById(gradeDto.getTeacherId()).orElse(null);
        if(teacherEntity==null)
            throw new ResourceNotFound("No such teacher exists");

        gradeEntity = GradeMapper.INSTANCE.toEntity(gradeDto);
        gradeEntity.setTeacherEntity(teacherEntity);
        gradeEntity = gradeRepository.save(gradeEntity);


        return GradeMapper.INSTANCE.toDto(gradeEntity);
    }




}
