package com.example.database.services.impl;

import com.example.database.dtos.ResultDto;
import com.example.database.entities.ResultEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.ResultMapper;
import com.example.database.repositories.ResultRepository;
import com.example.database.services.ResultService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ResultServiceImpl implements ResultService
{
    @Autowired
    ResultRepository resultRepository;


    @Override
    public ResultDto addResult(ResultDto resultDto) throws ResourceExist {
        ResultEntity entity = resultRepository.getResultById(resultDto.getId());
        if (entity != null)
            throw new ResourceExist("Result Id exist");
        entity = ResultMapper.INSTANCE.toEntity(resultDto);
        entity = resultRepository.save(entity);

        return ResultMapper.INSTANCE.toDto(entity);
    }


    @Override
    public ResultDto getResultById(Long id) throws ResourceNotFound {
        return Optional.ofNullable(resultRepository
                .getResultById(id))
                .map(ResultMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("Result not found"));
    }

    @Override
    public List<ResultDto> getResults() {
        return Optional.ofNullable(resultRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(ResultMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }
}
