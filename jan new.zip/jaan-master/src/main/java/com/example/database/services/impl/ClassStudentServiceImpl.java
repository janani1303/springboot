package com.example.database.services.impl;

import com.example.database.dtos.ClassStudentDto;
import com.example.database.entities.ClassRoomEntity;
import com.example.database.entities.ClassStudentEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.mappers.ClassStudentMapper;
import com.example.database.repositories.ClassRoomRepository;
import com.example.database.repositories.ClassStudentRepository;
import com.example.database.services.ClassStudentService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ClassStudentServiceImpl implements ClassStudentService {
    @Autowired
    ClassStudentRepository classStudentRepository;

    @Autowired
    ClassRoomRepository classRoomRepository;


    @Override
    public ClassStudentDto addClassStudent(ClassStudentDto classStudentDto) throws ResourceExist {
        System.out.println(classStudentDto.getClassRoomId());
        ClassStudentEntity classStudentEntity = classStudentRepository.getClassStudentById(classStudentDto.getId());
        if (classStudentEntity != null)
            throw new ResourceExist("ClassStudent Id exist");

        ClassRoomEntity classRoomEntity = classRoomRepository.findById(classStudentDto.getClassStudentId()).orElse(null);
        if(classRoomEntity==null)
            throw new ResourceNotFound("No such ClassRoom exists");

        classStudentEntity = ClassStudentMapper.INSTANCE.toEntity(classStudentDto);
        classStudentEntity.setClassRoomEntity(classRoomEntity);
        classStudentEntity = ClassRoomRepository.save(classRoomEntity);
        return ClassStudentMapper.INSTANCE.toDto(classStudentEntity);
    }


    @Override
    public ClassStudentDto getClassStudentById(Long id) throws ResourceNotFound {
        return Optional.ofNullable(classStudentRepository
                .getClassStudentById(id))
                .map(ClassStudentMapper.INSTANCE::toDto)
                .orElseThrow(() -> new ResourceNotFound("ClassStudent not found"));
    }

    @Override
    public List<ClassStudentDto> getClassStudents() {
        return Optional.ofNullable(classStudentRepository.findAll())
                .orElse(Collections.emptyList())
                .stream()
                .map(ClassStudentMapper.INSTANCE::toDto)
                .collect(Collectors.toList());
    }

}
