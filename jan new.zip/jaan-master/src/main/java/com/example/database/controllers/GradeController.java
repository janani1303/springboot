package com.example.database.controllers;
import com.example.database.dtos.GradeDto;
import com.example.database.dtos.TeacherDto;
import com.example.database.dtos.Validators.UserValidator;
import com.example.database.dtos.filters.UserView;
import com.example.database.entities.TeacherEntity;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;
import com.example.database.repositories.TeacherRepository;
import com.example.database.services.GradeService;
import com.fasterxml.jackson.annotation.JsonView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;


@RestController
@RequestMapping(value = "/api/v1/grade")
public class GradeController {

    private static final Logger LOGGER = LoggerFactory.getLogger( GradeController.class);

    @Autowired
    TeacherRepository teacherRepository;
    @Autowired
    GradeService gradeService;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ResponseEntity<String> hello() {
        return new ResponseEntity<>("hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/add-grade", method = RequestMethod.POST)
    public ResponseEntity<GradeDto> addGrade(@Validated(UserValidator.Create.class) @RequestBody @JsonView({ UserView.Create.class})  GradeDto createGradeDto) {
        System.out.println("The teacher id is"+createGradeDto.getTeacherId());
        GradeDto responseGradeDto = null;

        try {
            responseGradeDto =  gradeService. addGrade(createGradeDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }

        TeacherEntity teacherEntity=teacherRepository.findById(createGradeDto.getTeacherId()).orElse(null);
        responseGradeDto.setTeacherId(teacherEntity.getId());
        return new ResponseEntity<>(responseGradeDto, HttpStatus.OK);
    }

    @RequestMapping(value = "/get-all-grade", method = RequestMethod.GET)
    public ResponseEntity<List< GradeDto>> getAllGrade() {
        List< GradeDto>  GradeDtoList =  gradeService.getGrades();
        return new ResponseEntity<>(GradeDtoList, HttpStatus.OK);
    }

    @RequestMapping(value = "/{gradeName}", method = RequestMethod.GET)
    public ResponseEntity<GradeDto> getGrade( @PathVariable(value="gradeName")String gradeName) {
        GradeDto responseGradeDto = null;
        try {
            responseGradeDto = gradeService.getGradeByName(gradeName);
        } catch (ResourceNotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(responseGradeDto, HttpStatus.OK);
    }


    @RequestMapping(value = "/update-grade", method = RequestMethod.PUT)
    public ResponseEntity<GradeDto> updateGrade(@Validated( UserValidator.Update.class) @RequestBody @JsonView({ UserView.Update.class})GradeDto updateGradeDto) {
        GradeDto responseGradeDto = null;
        try {
            responseGradeDto =  gradeService.updateGrade(updateGradeDto);
        } catch (ResourceExist e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
        TeacherEntity teacherEntity=teacherRepository.findById(updateGradeDto.getTeacherId()).orElse(null);
        responseGradeDto.setTeacherId(teacherEntity.getId());
        return new ResponseEntity<>(responseGradeDto, HttpStatus.OK);
    }

//    @RequestMapping(value = "/delete-teacher/{id}", method = RequestMethod.DELETE)
//    public String delete(@PathVariable Long id) {
//        teacherService.deleteById(id);
//        return "Deleted";
//    }
//
//    @RequestMapping(value = "/delete-teacher", method = RequestMethod.DELETE)
//    public String deleteAll() {
//        teacherService.deleteAll();
//        return "Deleted";
//    }



}