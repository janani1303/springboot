package com.example.database.mappers;
import com.example.database.dtos.GradeDto;
import com.example.database.entities.GradeEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GradeMapper {
    GradeMapper INSTANCE = Mappers.getMapper(GradeMapper .class);

    GradeEntity toEntity(GradeDto gradeDto);
    GradeDto toDto( GradeEntity  gradeEntity);
}
