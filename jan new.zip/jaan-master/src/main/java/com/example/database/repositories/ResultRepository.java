package com.example.database.repositories;

import com.example.database.entities.ResultEntity;
import com.example.database.entities.StudentEntity;
import com.example.database.entities.SubjectGradeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ResultRepository extends JpaRepository<StudentEntity,Long>
{
    @Query(value = "select * from result where id =:inpId",nativeQuery = true)
    ResultEntity getSResultById(@Param("inpId") Long id);

//    @Query(value = "select * from Student where name =:name",nativeQuery = true)
//    StudentEntity getStudentByName(@Param("name") String name);

    ResultEntity getResultEntityById(Long Id);

    //ClassStudentEntity findByStudentName(String studentName);{
}
