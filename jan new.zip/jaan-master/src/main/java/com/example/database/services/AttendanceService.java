package com.example.database.services;


import com.example.database.dtos.AttendanceDto;
import com.example.database.dtos.GradeDto;
import com.example.database.exception.ResourceExist;
import com.example.database.exception.ResourceNotFound;

import java.util.List;

public interface  AttendanceService {


    AttendanceDto addAttendance(AttendanceDto attendanceDto) throws ResourceExist;

    AttendanceDto getAttendanceById(Long id) throws ResourceNotFound;

    List<AttendanceDto> getAttendances();

    AttendanceDto updateAttendance( AttendanceDto attendanceDto) throws ResourceExist;

//    void deleteById(Long id);
//
//    void deleteAll();
}
