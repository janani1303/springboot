package com.example.database.repositories.impl;
import com.example.database.entities.StudentEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class StudentRepositoryImpl{
    @PersistenceContext
    private EntityManager entityManager;

    public StudentEntity findByStudentName(String name) {
        Query query = entityManager.createNativeQuery("select * from student where name = " + name, StudentEntity.class);
        return (StudentEntity)  query.getSingleResult();
    }

}
