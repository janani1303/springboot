package com.example.database.repositories.impl;

import com.example.database.entities.ResultEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class ResultRepositoryImpl
{
    @PersistenceContext
    private EntityManager entityManager;

    public ResultEntity findByResultId(Long id) {
        Query query = entityManager.createNativeQuery("select * from result where id = " + id, ResultEntity.class);
        return (ResultEntity)  query.getSingleResult();
    }
}
