package com.example.database.dtos.Validators;

public class UserValidator {
    public interface Create{}
    public interface Login{}
    public interface Update{}
}
